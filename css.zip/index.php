<?php include 'include/header.php' ?>

<div id="carouselslider" class="carousel slide" data-ride="carousel" data-interval="3000">

    <nav class="px-1 px-md-5 z-10">
        <div class="d-flex justify-content-between align-items-center h-100">
            <div class="position-relative">
            <div class="logo-container">
                <a href="#" class="logo d-block">
                    <img src="images/logonew.png" class="object-contain" alt="">
                </a>
            </div>
                </div>
            <div class="d-block d-md-none">
                <button name="test" type="button" class="btn btn-dark-blue" id="side-bar-open"> <i
                        class="fa fa-bars"></i></button>
            </div>

            <div class="align-items-center d-none d-md-flex">
                <div class="d-none d-lg-flex align-items-top mr-4">
                    <div class="mr-2">
                        <div class="navbar-icon p-1">
                            <img src="icons/location.png" class="object-contain" alt="">
                        </div>
                    </div>
                    <div>
                        <p class="h6">VELACHERY</p>
                        <p class="text-secondary">PALLIKARANAI CHENNAI.</p>
                    </div>
                </div>
                <div class="d-flex align-items-top">
                    <div class="mr-2">
                        <div class="navbar-icon p-2">
                            <img src="icons/mail.png" class="object-contain" alt="">
                        </div>
                    </div>
                    <div>
                        <p class="h6">motherteam12@gmail.com</p>
                        <p class="text-secondary">Office Hour 09:00am - 05:00pm</p>
                    </div>
                </div>

            </div>
        </div>
    </nav>
    <ol class="carousel-indicators">
        <li data-target="#carouselslider" data-slide-to="0" class="active"></li>
        <li data-target="#carouselslider" data-slide-to="1"></li>
        <li data-target="#carouselslider" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item position-relative active">
            <img src="images/sliders/slider-img-1.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">

                    <p class="carousel-title mt-3">Excavating Excellence<br>Every Time</p>
                    <p class="carousel-para h6">Your Trusted Partner for Precision Earthworks, Excavation, and Material
                        Supply.
                    </p>

                </div>
            </div>
        </div>
        <div class="carousel-item position-relative ">
            <img src="images/sliders/slider-img-2.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">

                    <p class="carousel-title mt-3">Shaping Landscapes<br>Building Dreams</p>
                    <p class="carousel-para h6">Bringing Your Projects to Life, Safely and Sustainably. </p>

                </div>
            </div>
        </div>
        <div class="carousel-item position-relative">
            <img src="images/sliders/slider-img-3.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">
                    <p class="carousel-title mt-3">Quality, Precision,<br>and Commitment</p>
                    <p class="carousel-para h6">We provide Good quality service, at affordable price.</p>
                </div>
            </div>
        </div>
        <div class="carousel-item position-relative">
            <img src="images/sliders/slider-img-5.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">

                    <p class="carousel-title mt-3">27 years of <br>Experience</p>
                    <p class="carousel-para h6">we are the The Earthwork Experts you need.</p>

                </div>
            </div>
        </div>

    </div>
</div>

<style>
    #carouselslider {
        z-index: 10;
    }

    nav {
        position: absolute;
        top: 0;
        z-index: 20;
        background-color: white;
        width: 100%;
        height: 15vh;

    }

    .main_container {
        display: flex;
        position: relative;
    }

    .left_side_container {
        position: sticky;
        top: 0;
        width: 25vw;
        height: 100vh;
        /* background-color: aliceblue; */
        padding: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .right_side_container {
        width: 75vw;
        display: inline-block;
        position: relative;
        box-sizing: border-box;
    }

    .main_sections {
        height: 90vh;
        padding: 14px;
        border-bottom: 1px solid #0254898a;
    }

    .containers_heading {
        position: fixed;
        top: 0;
        left: 0;
        width: 25vw;
        height: 100vh;
        background-color: aliceblue;
        padding: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        background-repeat: no-repeat;
        background-position: right;
        background-size: cover;
    }

    .containers_heading h2 {
        transform: rotate(270deg);
        font-size: 80px;
        color: white;

    }


    .main_nav {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
    }

    .mainNav_btn {
        transition: all ease .3s;
        width: 20%;
        background-color: #f5f5f5;
        color: black;
        height: 10vh;
        display: flex;
        text-align: center;
        justify-content: center;
        align-items: center;
    }

    .mainNav_btn:hover {
        background-color: #025489;
        color: white;
    }

    .main_nav .active {
        background-color: #025489;
        color: white;
    }

    .left_nav_image {
        position: absolute;
        top: 0;
        left: 0;
        object-fit: cover;
        height: 100%;
        width: 100%;
        z-index: -1;
        filter: brightness(.7);
    }

    .main_section_heading {
        font-size: 38px;
        font-weight: 600;
    }

    .logo-container {
        background-color: white;
        position: absolute;
        top: -40px;
    }

    .z--1 {
        z-index: -1;
    }

    /* media area */

    @media screen and (max-width: 1200px) {}

    @media screen and (max-width: 998px) {}

    @media screen and (max-width: 768px) {}

    @media screen and (max-width: 600px) {
        .sticky-nav {
            display: none;
        }

        .main_sections {
            height: 100vh;
        }

        .left_side_container {
            display: none;
        }

        .right_side_container {
            width: 100vw;
        }

    }
</style>


<section class="main_container">
    <div class="left_side_container">
        <div class="containers_heading">
            <h2>About</h2>
            <img src="images/about_img.png" class="left_nav_image">
        </div>
    </div>

    <div class="right_side_container">
        <div class="sticky-nav">
            <ul class="d-flex align-items-center main_nav">
                <li class="mainNav_btn active main_nav1" data-section="about">About</li>
                <li class="mainNav_btn main_nav2" data-section="services">Services</li>
                <li class="mainNav_btn main_nav3" data-section="projects">Projects</li>
                <li class="mainNav_btn main_nav4" data-section="gallery">Gallery</li>
                <li class="mainNav_btn main_nav5" data-section="contact">Contact</li>
            </ul>
        </div>
        <div class="main_sections" id="about" data-side_heading="About" data-nav_active="main_nav1">
            <p class="main_section_heading my-3">About US</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum, rerum.</p>

            <div class="container mt-lg-5 mt-3">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="about-img">
                            <img src="images/new_img/mt_images (9).jpg" class="object-cover" alt="">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <p class="p-2">
                            In the late 1990s, the story of Mother Transport began with a passionate and hardworking
                            individual, Mr.
                            R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor
                            contractor, and by
                            2001, he was handling the supply of bulk materials with just a single lorry. A visionary in
                            the making,
                            he expanded his endeavors, diving into both labor contracting and material supply, laying
                            the foundation
                            for Mother Transport.
                        </p>
                        <button class="btn btn-mtem mt-4 ml-3">Read More</button>
                    </div>
                </div>
            </div>

        </div>
        <div class="main_sections" id="services" data-side_heading="Services" data-nav_active="main_nav2">
            <p class="main_section_heading">Services Offere</p>
            <p class="mt-3">
                In the late 1990s, the story of Mother Transport began with a passionate and hardworking individual, Mr.
                R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and by
                2001, he was handling the supply of bulk materials with just a single lorry. A visionary in the making,
                he expanded his endeavors, diving into both labor contracting and material supply, laying the foundation
                for Mother Transport.
            </p>
        </div>
        <div class="main_sections" id="projects" data-side_heading="Projects" data-nav_active="main_nav3">
            <p class="main_section_heading">Our Projects</p>
            <p class="mt-3">
                In the late 1990s, the story of Mother Transport began with a passionate and hardworking individual, Mr.
                R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and by
                2001, he was handling the supply of bulk materials with just a single lorry. A visionary in the making,
                he expanded his endeavors, diving into both labor contracting and material supply, laying the foundation
                for Mother Transport.
            </p>
        </div>
        <div class="main_sections" id="gallery" data-side_heading="Gallery" data-nav_active="main_nav4">
            <p class="main_section_heading">Gallery</p>
            <p class="mt-3">
                In the late 1990s, the story of Mother Transport began with a passionate and hardworking individual, Mr.
                R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and by
                2001, he was handling the supply of bulk materials with just a single lorry. A visionary in the making,
                he expanded his endeavors, diving into both labor contracting and material supply, laying the foundation
                for Mother Transport.
            </p>
        </div>
        <div class="main_sections" id="contact" data-side_heading="Contact" data-nav_active="main_nav5">
            <p class="main_section_heading">Contact</p>
            <p class="mt-3">
                In the late 1990s, the story of Mother Transport began with a passionate and hardworking individual, Mr.
                R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and by
                2001, he was handling the supply of bulk materials with just a single lorry. A visionary in the making,
                he expanded his endeavors, diving into both labor contracting and material supply, laying the foundation
                for Mother Transport.
            </p>
        </div>
    </div>
</section>



<?php include 'include/footer.php' ?>