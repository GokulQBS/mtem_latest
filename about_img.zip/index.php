<?php include 'include/header.php' ?>

<div id="HomeCarousel" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#HomeCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#HomeCarousel" data-slide-to="1"></li>
        <li data-target="#HomeCarousel" data-slide-to="2"></li>
        <li data-target="#HomeCarousel" data-slide-to="3"></li>
        <li data-target="#HomeCarousel" data-slide-to="4"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
        <div class="carousel-item active">
            <img src="images/sliders/slider-img-1.png" class="object-cover" alt="First slide">
            <div class="carousel-caption">
                Text
            </div>
        </div>
        <div class="carousel-item">
            <img src="images/sliders/slider-img-2.png" class="object-cover" alt="Second slide">
            <div class="carousel-caption">
                Text
            </div>
        </div>
        <div class="carousel-item">
            <img src="images/sliders/slider-img-3.png" class="object-cover" alt="Fourth slide">
            <div class="carousel-caption">
                Text
            </div>
        </div>
        <div class="carousel-item">
            <img src="images/sliders/slider-img-4.jpg" class="object-cover" alt="Fifth slide">
            <div class="carousel-caption">
                Text
            </div>
        </div>
        <div class="carousel-item">
            <img src="images/sliders/slider-img-5.png" class="object-cover" alt="Sixth slide">
            <div class="carousel-caption">
                Text
            </div>
        </div>
    </div>
    <a class="carousel-control-prev" href="#HomeCarousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#HomeCarousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<div class=" mt-5">
    <div class="container">
        <div class="row">
        <div class="order-2 order-md-1 col-lg-6 col-md-12 my-3">
            <h2 class="h3">About Us</h2>
            <p class="my-2">In the late 1990s, the story of Mother Transport began with a passionate and hardworking individual, Mr.
                R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and by
                2001, he was handling the supply of bulk materials with just a single lorry. A visionary in the making,
                he expanded his endeavors, diving into both labor contracting and material supply, laying the foundation
                for Mother Transport.</p>
            <p class="">
                After a brief hiatus, Mr. KUPPUSAMY resumed his entrepreneurial journey in 2013 with renewed vigor. This
                time, he diversified Mother Transport's services by venturing into excavation and earthmoving jobs,
                utilizing his own fleet of vehicles. This strategic move marked a significant milestone in the company's
                evolution, showcasing Mr. KUPPUSAMY's adaptability and commitment to meeting the dynamic needs of the
                industry. Today, Mother Transport stands as a testament to his dedication and foresight in building a
                versatile and successful business.</p>
                <button class="btn btn-primary mt-3">Read More</button>
        </div>
        <div class="order-1 order-md-2 col-lg-6 col-md-12 p-2 align-center">
            <div class="about-img">
                <img src="images/homepage/about_img.png" class="object-cover" alt="">
            </div>
        </div>
    </div>
    </div>
</div>

<div class=" mt-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 p-2 align-center">
            <div class="about-img">
                <img src="images/new_img/mt_images (9).jpg" class="object-cover" alt="">
            </div>
        </div>
        <div class="col-lg-6 col-md-12 my-3">
            <h2 class="h3">Why Us</h2>
            <p class="my-2">In the late 1990s, the story of Mother Transport began with a passionate and hardworking individual, Mr.
                R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and by
                2001, he was handling the supply of bulk materials with just a single lorry. A visionary in the making,
                he expanded his endeavors, diving into both labor contracting and material supply, laying the foundation
                for Mother Transport.</p>
            <p class="">
                After a brief hiatus, Mr. KUPPUSAMY resumed his entrepreneurial journey in 2013 with renewed vigor. This
                time, he diversified Mother Transport's services by venturing into excavation and earthmoving jobs,
                utilizing his own fleet of vehicles. This strategic move marked a significant milestone in the company's
                evolution, showcasing Mr. KUPPUSAMY's adaptability and commitment to meeting the dynamic needs of the
                industry. Today, Mother Transport stands as a testament to his dedication and foresight in building a
                versatile and successful business.</p>
                <button class="btn btn-primary mt-3">Read More</button>
        </div>
        
    </div>
    </div>
    
</div>

<div class="d-md-flex justify-content-between align-items-center mt-5">

    <div class="side_content p-2 p-md-5">
    <h2 class="h3">Services</h2>
        <h3 class="my-3">Excavation Works</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi vel sed impedit obcaecati nihil enim maxime id
            quibusdam dolorum possimus fugit, dolorem nostrum aliquam cupiditate soluta. Sequi modi error tenetur?
            Accusamus error neque suscipit vero consequatur modi perspiciatis eligendi! Consequatur quis ex labore iste
            mollitia eaque porro rem, optio corporis, vel illum reiciendis totam repellendus.</p>
    </div>
    <div class="side_img excavation_services_img">

    </div>
</div>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
    <div class="side_img order-2 order-md-1 material_supply_services_img">

    </div>
    <div class="side_content order-1 order-md-2 p-2 p-md-5">
    <h3 class="my-3">Materials Supply</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi vel sed impedit obcaecati nihil enim maxime id
            quibusdam dolorum possimus fugit, dolorem nostrum aliquam cupiditate soluta. Sequi modi error tenetur?
            Accusamus error neque suscipit vero consequatur modi perspiciatis eligendi! Consequatur quis ex labore iste
            mollitia eaque porro rem, optio corporis, vel illum reiciendis totam repellendus.</p>
    </div>

</div>

<div class="d-md-flex justify-content-between align-items-center">
    <div class="side_content p-2 p-md-5">
    <h3 class="my-3">Road Works</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi vel sed impedit obcaecati nihil enim maxime id
            quibusdam dolorum possimus fugit, dolorem nostrum aliquam cupiditate soluta. Sequi modi error tenetur?
            Accusamus error neque suscipit vero consequatur modi perspiciatis eligendi! Consequatur quis ex labore iste
            mollitia eaque porro rem, optio corporis, vel illum reiciendis totam repellendus.</p>
    </div>
    <div class="side_img road_services_img">

    </div>
</div>


<div class="my-5 py-5 text-center h1">
    Section
</div>
<div class="my-5 py-5 text-center h1 bg-light">
    Section
</div>

<?php include 'include/footer.php' ?>

<script>
    var mySlider = $('.pogoSlider').pogoSlider();
</script>