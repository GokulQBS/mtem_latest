<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />
  <link rel="stylesheet" href="css/style.css">
  <link rel="icon" href="images/logo.png" sizes="32x32" />
  <link rel="icon" href="images/logo.png" sizes="192x192" />
  <meta name="description" content="">
  <meta name="keywords" content="">
  <title>Motherstransport</title>
</head>

<body>
  <!-- aside -->
  <!-- <aside class="side-contents">
    <button class="btn btn-dark-blue close-btn" id="side-bar-closer">
      <i class="fa-solid fa-x"> <span class="fs-0">close sidebar</span></i>
    </button>
    <ul>
      <li class="h3"><a href="#">Links</a></li>
      <li class="fade-up-links"><a href="index.php">Home</a></li>
      <li class="fade-up-links"><a href="about.php">About</a></li>
      <li class="fade-up-links"><a href="contact.php">Contact</a></li>
      <li class="fade-up-links"><a href="gallery.php">Gallery</a></li>
      <li class="fade-up-links"><a href="services.php">Services</a></li>
      <li class="fade-up-links"><a href="completedProjects.php">Completed Projects</a></li>
      <li class="fade-up-links"><a href="ongoingProjects.php">Ongoing Projects</a></li>
    </ul>
  </aside> -->

  <main>
    <nav class="d-flex justify-content-between align-items-center align-items-md-end">
      <div class="logo_container"><img src="images/logonew.png" class="logo" alt=""></div>

      <div>
        <div class="d-none align-items-center justify-content-center d-md-flex pb-4 mr-3 pr-md-0">
          <div class="d-flex align-items-top mr-4">
            <div class="mr-2">
              <div class="navbar-icon p-1">
                <img src="icons/location.png" class="object-contain" alt="">
              </div>
            </div>
            <div>
              <p class="h6">VELACHERY</p>
              <p class="text-secondary">PALLIKARANAI CHENNAI.</p>
            </div>
          </div>
          <div class="d-flex align-items-top">
            <div class="mr-2">
              <div class="navbar-icon p-2">
                <img src="icons/mail.png" class="object-contain" alt="">
              </div>
            </div>
            <div>
              <p class="h6">motherteam12@gmail.com</p>
              <p class="text-secondary">Office Hour 09:00am - 05:00pm</p>
            </div>
          </div>
        </div>
        <div class="align-items-center justify-content-end main-nav-links d-none d-lg-flex">
          <div><a href="index.php">Home</a></div>
          <div><a href="about.php">About</a></div>
          <div><a href="services.php">Services</a></div>
          <div><a href="completedProjects.php">Projects</a></div>
          <div><a href="contact.php">Contact</a></div>
        </div>
      </div>
      <div class="d-block d-md-none pr-3">
        <button class="btn btn-primary" id="side-bar-open"><i class="fa fa-bars"></i></button>
      </div>
    </nav>

    <aside class="side-bar">
    <button class="btn btn-primary close-btn" id="side-bar-closer">
            <i class="fa fa-x"></i>
        </button>
        <ul>
            <li class="h3"><a href="#">Links</a></li>
            <li class="fade-up-links"><a href="index.php">Home</a></li>
            <li class="fade-up-links"><a href="about.php">About</a></li>
            <li class="fade-up-links"><a href="contact.php">Contact</a></li>
            <li class="fade-up-links"><a href="gallery.php">Gallery</a></li>
            <li class="fade-up-links"><a href="services.php">Services</a></li>
            <li class="fade-up-links"><a href="completedProjects.php">Completed Projects</a></li>
            <li class="fade-up-links"><a href="ongoingProjects.php">Ongoing Projects</a></li>
        </ul>
    </aside>