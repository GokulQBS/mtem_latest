<?php include 'include/header.php' ?>

<div id="carouselslider" class="carousel slide" data-ride="carousel" data-interval="3000">

    <!-- <nav class="px-1 px-md-5 z-10">
        <div class="d-flex justify-content-between align-items-center h-100">
            <div class="position-relative">
            <div class="logo-container">
                <a href="#" class="logo d-block">
                    <img src="images/logonew.png" class="object-contain" alt="">
                </a>
            </div>
                </div>
            <div class="d-block d-md-none">
                <button name="test" type="button" class="btn btn-dark-blue" id="side-bar-open"> <i
                        class="fa fa-bars"></i></button>
            </div>

            <div class="align-items-center d-none d-md-flex">
                <div class="d-none d-lg-flex align-items-top mr-4">
                    <div class="mr-2">
                        <div class="navbar-icon p-1">
                            <img src="icons/location.png" class="object-contain" alt="">
                        </div>
                    </div>
                    <div>
                        <p class="h6">VELACHERY</p>
                        <p class="text-secondary">PALLIKARANAI CHENNAI.</p>
                    </div>
                </div>
                <div class="d-flex align-items-top">
                    <div class="mr-2">
                        <div class="navbar-icon p-2">
                            <img src="icons/mail.png" class="object-contain" alt="">
                        </div>
                    </div>
                    <div>
                        <p class="h6">motherteam12@gmail.com</p>
                        <p class="text-secondary">Office Hour 09:00am - 05:00pm</p>
                    </div>
                </div>

            </div>
        </div>
    </nav> -->

    <ol class="carousel-indicators">
        <li data-target="#carouselslider" data-slide-to="0" class="active"></li>
        <li data-target="#carouselslider" data-slide-to="1"></li>
        <li data-target="#carouselslider" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item position-relative active">
            <img src="images/sliders/slider-img-1.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">

                    <p class="carousel-title mt-3">Excavating Excellence<br>Every Time</p>
                    <p class="carousel-para h6">Your Trusted Partner for Precision Earthworks, Excavation, and Material
                        Supply.
                    </p>

                </div>
            </div>
        </div>
        <div class="carousel-item position-relative ">
            <img src="images/sliders/slider-img-2.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">

                    <p class="carousel-title mt-3">Shaping Landscapes<br>Building Dreams</p>
                    <p class="carousel-para h6">Bringing Your Projects to Life, Safely and Sustainably. </p>

                </div>
            </div>
        </div>
        <div class="carousel-item position-relative">
            <img src="images/sliders/slider-img-3.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">
                    <p class="carousel-title mt-3">Quality, Precision,<br>and Commitment</p>
                    <p class="carousel-para h6">We provide Good quality service, at affordable price.</p>
                </div>
            </div>
        </div>
        <div class="carousel-item position-relative">
            <img src="images/sliders/slider-img-5.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">

                    <p class="carousel-title mt-3">27 years of <br>Experience</p>
                    <p class="carousel-para h6">we are the The Earthwork Experts you need.</p>

                </div>
            </div>
        </div>

    </div>
</div>


<section class="main_container">
    <div class="left_side_container">
        <div class="containers_heading">
            <h2>About</h2>
            <img src="images/about_img.png" class="left_nav_image">
        </div>
    </div>

    <div class="right_side_container">
        <div class="sticky-nav">
            <ul class="d-flex align-items-center main_nav">
                <li class="mainNav_btn active main_nav1" data-section="about">About</li>
                <li class="mainNav_btn main_nav2" data-section="services">Services</li>
                <li class="mainNav_btn main_nav3" data-section="projects">Projects</li>
                <li class="mainNav_btn main_nav4" data-section="story">Story</li>
                <li class="mainNav_btn main_nav5" data-section="client">Client</li>
            </ul>
        </div>
        <div class="main_sections" id="about" data-side_heading="About" data-nav_active="main_nav1">
            <div class="container">
                <p class="main_section_heading my-3">About US</p>
                <p class="background_text">About us</p>
                <p>In the very Beginning</p>
                <i class="main_section_underline"></i>
            </div>
            <div class="container mt-lg-5 mt-3">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="about-img">
                            <img src="images/new_img/mt_images (9).jpg" class="object-cover" alt="">
                        </div>
                    </div>
                    <div class="col-lg-6 bg-white">
                        <p class="p-2">
                            In the late 1990s, the story of Mother Transport began with a passionate and hardworking
                            individual, Mr.
                            R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor
                            contractor, and by
                            2001, he was handling the supply of bulk materials with just a single lorry. A visionary in
                            the making,
                            he expanded his endeavors, diving into both labor contracting and material supply, laying
                            the foundation
                            for Mother Transport.
                        </p>
                        <button class="btn btn-mtem mt-4 ml-3">Read More</button>
                    </div>
                </div>
            </div>
            <ul class="row mt-3 py-3 text-center bg-light">
                <li class="col-lg-3 mb-2 mb-md-0">
                    <p class="h3 mb-0">33+</p>
                    <p class="text-mtem font-weight-bold">Projects Done</p>
                </li>
                <li class="col-lg-3 mb-2 mb-md-0">
                    <p class="h3 mb-0">33+</p>
                    <p class="text-mtem font-weight-bold">Happy Customers</p>
                </li>
                <li class="col-lg-3 mb-2 mb-md-0">
                    <p class="h3 mb-0">56+</p>
                    <p class="text-mtem font-weight-bold">Active Vehicles</p>
                </li>
                <li class="col-lg-3 mb-2 mb-md-0">
                    <p class="h3 mb-0">27+</p>
                    <p class="text-mtem font-weight-bold">Years Of Experience</p>
                </li>
            </ul>

        </div>
        <div class="main_sections" id="services" data-side_heading="Services" data-nav_active="main_nav2">

            <div class="container">
                <p class="main_section_heading my-3">Services we offer</p>
                <p class="background_text">Services</p>
                <p>In the very Beginning</p>
                <i class="main_section_underline"></i>

                <p class="mt-3">
                    At Mothers Transport, we offer a comprehensive suite of construction services to bring your vision
                    to
                    life. From sturdy foundations to expert construction, reliable material supply, efficient
                    demolitions,
                    and road projects, we've got it all covered.
                </p>
                <p class="mt-3 mb-5">
                    we don't just provide services, we forge partnerships. We are your trusted partner in progress,
                    dedicated to delivering excellence in every service we offer. Whether you're planning a new project
                    or
                    seeking support for your transportation and infrastructure needs, we are here to elevate your
                    endeavors.
                </p>

                <div class="row our_services">
                    <div class="col-lg-4">
                        <div class="services_img">
                            <img src="images/services/road_works.jpg" class="object-cover" alt="">
                            <div class="services_content d-flex justify-content-center align-items-center">
                                <p>Road Works</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="services_img">
                            <img src="images/services/road_works.jpg" class="object-cover" alt="">
                            <div class="services_content d-flex justify-content-center align-items-center">
                                <p>Material supply</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="services_img">
                            <img src="images/services/road_works.jpg" class="object-cover" alt="">
                            <div class="services_content d-flex justify-content-center align-items-center">
                                <p>Excavation Works</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main_sections" id="projects" data-side_heading="Projects" data-nav_active="main_nav3">
            <div class="container">
                <p class="main_section_heading my-3">Projects</p>
                <p class="background_text">Projects</p>
                <p>At MTEM, our work speaks for itself.</p>
                <i class="main_section_underline"></i>
                <p class="mt-3">
                    We take pride in a rich portfolio of successfully completed projects that showcase our expertise,
                    dedication, and commitment to excellence. Explore some of our most notable achievements below:
                </p>
            </div>
        </div>
        <div class="main_sections" id="story" data-side_heading="Story" data-nav_active="main_nav4">
            <div class="container">
            <p class="main_section_heading my-3">Story</p>
                <p class="background_text">Story</p>
                <p>The Path that made us to be a great.</p>
                <i class="main_section_underline"></i>
            
            <p class="mt-3">
                In the late 1990s, the story of Mother Transport began with a passionate and hardworking individual, Mr.
                R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and by
                2001, he was handling the supply of bulk materials with just a single lorry. A visionary in the making,
                he expanded his endeavors, diving into both labor contracting and material supply, laying the foundation
                for Mother Transport.
            </p>
        </div>
        </div>
        <div class="main_sections" id="client" data-side_heading="client" data-nav_active="main_nav5">
            <div class="container">
            <p class="main_section_heading my-3">Clients</p>
                <p class="background_text">Client</p>
                <p>The Path that made us to be a great.</p>
                <i class="main_section_underline"></i>
            <p class="mt-3">
                In the late 1990s, the story of Mother Transport began with a passionate and hardworking individual, Mr.
                R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and by
                2001, he was handling the supply of bulk materials with just a single lorry. A visionary in the making,
                he expanded his endeavors, diving into both labor contracting and material supply, laying the foundation
                for Mother Transport.
            </p>
        </div>
        </div>
    </div>
</section>



<?php include 'include/footer.php' ?>